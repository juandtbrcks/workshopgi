"""
Buscador Inteligente de Imagenes - Grupo Infra
================================================
Databricks App: CLIP Multilingue + Mosaic AI Vector Search
"""

import os
import io
import base64
import logging

import gradio as gr
from PIL import Image
from sentence_transformers import SentenceTransformer

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
VECTOR_SEARCH_ENDPOINT = "busquedaimagenesvectorindex"
VECTOR_SEARCH_INDEX = "micatalogo.miesquema.image_search_index"
VOLUME_PATH = "/Volumes/micatalogo/miesquema/imagenesbuscador"
CLIP_MODEL_NAME = "sentence-transformers/clip-ViT-B-32-multilingual-v1"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Globals (lazy init)
# ---------------------------------------------------------------------------
_clip_model = None
_workspace_client = None
_vs_client = None


def get_clip_model():
    global _clip_model
    if _clip_model is None:
        logger.info("Loading CLIP model: %s", CLIP_MODEL_NAME)
        _clip_model = SentenceTransformer(CLIP_MODEL_NAME)
        logger.info("CLIP model loaded.")
    return _clip_model


def get_workspace_client():
    global _workspace_client
    if _workspace_client is None:
        from databricks.sdk import WorkspaceClient
        _workspace_client = WorkspaceClient()
    return _workspace_client


def get_vs_client():
    global _vs_client
    if _vs_client is None:
        from databricks.vector_search.client import VectorSearchClient
        if os.environ.get("DATABRICKS_APP_NAME"):
            _vs_client = VectorSearchClient(
                workspace_url=f"https://{os.environ.get('DATABRICKS_HOST', '')}",
                service_principal_client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
                service_principal_client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET"),
            )
        else:
            from databricks.sdk import WorkspaceClient
            w = WorkspaceClient()
            _vs_client = VectorSearchClient(
                workspace_url=w.config.host,
                personal_access_token=w.config.token,
            )
    return _vs_client


def encode_text(query):
    return get_clip_model().encode(query, normalize_embeddings=True).tolist()


def load_image_b64(file_path):
    """Load image from UC Volume and return as base64 data URI."""
    try:
        w = get_workspace_client()
        resp = w.files.download(file_path)
        img_bytes = resp.contents.read()
        b64 = base64.b64encode(img_bytes).decode()
        return f"data:image/jpeg;base64,{b64}"
    except Exception as e:
        logger.error("Failed to load %s: %s", file_path, e)
        return None


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def do_search(query, num_results):
    if not query or not query.strip():
        return "<p style='color:#888;text-align:center;padding:40px;'>Escribe una consulta para buscar imagenes.</p>"

    query = query.strip()
    logger.info("Search: '%s' (top %d)", query, num_results)

    try:
        embedding = encode_text(query)
        logger.info("Embedding[0:5]: %s", [round(x, 4) for x in embedding[:5]])
    except Exception as e:
        return f"<p style='color:red;'>Error al codificar consulta: {e}</p>"

    try:
        vs = get_vs_client()
        index = vs.get_index(endpoint_name=VECTOR_SEARCH_ENDPOINT, index_name=VECTOR_SEARCH_INDEX)
        results = index.similarity_search(
            query_vector=embedding,
            columns=["image_id", "file_name", "file_path"],
            num_results=int(num_results),
        )
    except Exception as e:
        logger.error("VS error: %s", e, exc_info=True)
        return f"<p style='color:red;'>Error en busqueda vectorial: {e}</p>"

    data = results.get("result", {}).get("data_array", [])
    logger.info("Results: %d rows", len(data))
    for r in data:
        logger.info("  %s score=%s", r[1], r[-1])
    if not data:
        return "<p style='color:#888;text-align:center;padding:40px;'>No se encontraron resultados.</p>"

    # Build HTML grid
    cards = []
    for row in data:
        image_id, file_name, file_path = row[0], row[1], row[2]
        score = row[-1]
        score_pct = score * 100 if score <= 1.0 else score

        img_src = load_image_b64(file_path)
        if img_src:
            cards.append(f"""
            <div style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1);transition:transform 0.2s;">
                <img src="{img_src}" style="width:100%;height:220px;object-fit:cover;"/>
                <div style="padding:10px 14px;">
                    <div style="font-weight:600;font-size:14px;color:#1a237e;">{file_name}</div>
                    <div style="font-size:13px;color:#666;margin-top:4px;">Similitud: <b>{score_pct:.1f}%</b></div>
                </div>
            </div>""")

    html = f"""
    <div style="margin-bottom:16px;padding:12px 16px;background:#e8eaf6;border-radius:8px;border-left:4px solid #1a237e;">
        <b>{len(cards)}</b> resultados para: "<i>{query}</i>"
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
        {"".join(cards)}
    </div>"""
    return html


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

EXAMPLES = [
    ["trabajadores sin casco de seguridad"],
    ["maquinas con humo o fuego visible"],
    ["tanques de oxigeno almacenados"],
    ["maquinaria pesada operando, montacargas"],
    ["area de trabajo limpia y ordenada"],
    ["tuberias y valvulas industriales"],
    ["personas trabajando en alturas"],
    ["equipo de proteccion personal"],
]

CSS = """
.gradio-container { max-width: 1100px !important; margin: auto !important; }
.header-banner {
    background: linear-gradient(135deg, #1a237e 0%, #0d47a1 50%, #01579b 100%);
    color: white; padding: 28px 32px; border-radius: 12px; margin-bottom: 20px; text-align: center;
}
.header-banner h1 { margin: 0 0 8px 0; font-size: 28px; }
.header-banner p { margin: 0; font-size: 15px; opacity: 0.9; }
"""

def build_ui():
    with gr.Blocks(title="Buscador Inteligente — Grupo Infra", css=CSS) as demo:
        gr.HTML("""
        <div class="header-banner">
            <h1>Buscador Inteligente de Imagenes</h1>
            <p>Grupo Infra &mdash; CLIP Multilingue + Databricks Mosaic AI Vector Search</p>
        </div>""")

        with gr.Row():
            with gr.Column(scale=4):
                query_input = gr.Textbox(
                    label="Consulta en espanol",
                    placeholder="Ej: trabajadores sin casco de seguridad, maquinas con humo...",
                    lines=2,
                )
            with gr.Column(scale=1):
                num_results = gr.Slider(minimum=1, maximum=15, value=5, step=1, label="Resultados")
                search_btn = gr.Button("Buscar", variant="primary", size="lg")

        gr.Examples(examples=EXAMPLES, inputs=query_input, label="Ejemplos de consultas")

        results_html = gr.HTML(
            value="<p style='color:#888;text-align:center;padding:40px;'>Los resultados apareceran aqui.</p>"
        )

        search_btn.click(fn=do_search, inputs=[query_input, num_results], outputs=results_html)
        query_input.submit(fn=do_search, inputs=[query_input, num_results], outputs=results_html)

        gr.HTML("""
        <div style="text-align:center;margin-top:24px;padding:12px;color:#666;font-size:13px;">
            Powered by Databricks Mosaic AI Vector Search &bull;
            Modelo: clip-ViT-B-32-multilingual-v1
        </div>""")

    return demo


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    logger.info("Starting Buscador Inteligente de Imagenes ...")
    get_clip_model()

    import uvicorn
    from fastapi import FastAPI

    port = int(os.environ.get("PORT", 8000))
    demo = build_ui()

    fastapi_app = FastAPI()

    @fastapi_app.get("/health")
    def health():
        return {"status": "healthy"}

    app = gr.mount_gradio_app(fastapi_app, demo, path="/")

    logger.info("Starting uvicorn on port %d", port)
    uvicorn.run(app, host="0.0.0.0", port=port)
